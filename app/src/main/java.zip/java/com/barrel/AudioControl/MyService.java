package com.barrel.AudioControl;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.baidu.aip.asrwakeup3.core.recog.MyRecognizer;
import com.baidu.aip.asrwakeup3.core.recog.listener.IRecogListener;
import com.baidu.aip.asrwakeup3.core.recog.listener.MessageStatusRecogListener;
import com.baidu.speech.asr.SpeechConstant;

import java.util.LinkedHashMap;
import java.util.Map;

public class MyService extends AccessibilityService {

    private static final String TAG = "AudioControl";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo config = new AccessibilityServiceInfo();
        //配置监听的事件类型为界面变化/点击事件
        config.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_VIEW_CLICKED;
        config.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        if (Build.VERSION.SDK_INT >= 18) {
            config.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
        }
        setServiceInfo(config);
    }

    int i = 0;

    protected MyRecognizer myRecognizer;

    /**
     * 开始录音，点击“开始”按钮后调用。
     */
    protected void start() {
        Map<String, Object> params = new LinkedHashMap<String, Object>();
        params.put(SpeechConstant.ACCEPT_AUDIO_DATA, false);//是否保存音频
        params.put(SpeechConstant.DISABLE_PUNCTUATION, false);//是否禁用标点符号，在选择输入法模型的前提下生效【不禁用的话，说完一段话，就自带标点符号】
        params.put(SpeechConstant.ACCEPT_AUDIO_VOLUME, false);//暂时不知道什么意思
        params.put(SpeechConstant.PID, 1536); // 普通话 search搜索模型，默认，适用于短句，无逗号，可以有语义
        //params.put(SpeechConstant.VAD_ENDPOINT_TIMEOUT, 0); // 长语音，建议搭配input输入法模型
        myRecognizer.start(params);
    }
    /**
     * 开始录音后，手动停止录音。SDK会识别在此过程中的录音。点击“停止”按钮后调用。
     */
    private void stop() {
        myRecognizer.stop();
    }
    /**
     * 开始录音后，取消这次录音。SDK会取消本次识别，回到原始状态。点击“取消”按钮后调用。
     */
    private void cancel() {
        myRecognizer.cancel();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event)
    {
        Log.i(TAG, "time"+ i );
        AccessibilityNodeInfo nodeInfo = event.getSource();//当前界面的可访问节点信息
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
        {
            ComponentName componentName = new ComponentName(event.getPackageName().toString(), event.getClassName().toString());
            Log.i(TAG, "当前Activity为：" + componentName.flattenToShortString());
            if (componentName.flattenToShortString().equals("com.smartcar.carrecorder/.sc_activity.SCCarRecorderAct")){
                Log.i(TAG, "是这个界面了");
                start();
                }
        }
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED)
        {

        }
        i++;
    }

    private ActivityInfo tryGetActivity(ComponentName componentName) {
        try {
            return getPackageManager().getActivityInfo(componentName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    @Override
    public void onInterrupt() {
    }



}

